# Restful APIs for HTTP services (CRUD web services)


In this project, there are four HTTP request types established for imposing RESTFUL APIs, i.e. POST, GET, PUT and DELETE ---->


1. POST 
       Purpose: A POST request is used for creating new inventory documents and recording in MongoDB as the database.
       Path URL: /api/stock/create
       Test: curl -X POST -H "Content-Type: application/json" --data '{"id":"4","name":"ABC Powerbank", "cat.":"electronics", "status":"pending", "location":"Taipo", "date":"23 Nov 2023"}' localhost:8099/api/stock/create

2. GET
       Purpose: A GET request is used for finding stored inventory records from MongoDB.
       Path URL: /api/stock/read
       Test: curl -X GET -H "Content-Type: application/json" --data '{"id":"4","name":"ABC Powerbank", "cat":"electronics", "status":"pending", "location":"Taipo", "date":"23 Nov 2023"}' localhost:8099/api/stock/read

3. PUT
       Purpose: A PUT request is used for updating/editing stored inventory records.
       Path URL: /api/stock/update/id/:id
       Test: curl -X PUT -H "Content-Type: application/json" --data '{"id":"4","name":"DEF Router", "cat":"accessories", "status":"pending", "location":"Taipo", "date":"23 Nov 2023"}' localhost:8099/api/stock/update/id/4

4. DELETE
       Purpose: A DELETE request is used for erasing existing records in MongoDB.
       Path URL: /api/stock/delete
       Test: curl -X DELETE -H "Content-Type: application/json" --data '{"id":"4","name":"DEF Router", "cat":"accessories", "status":"pending", "location":"Taipo", "date":"23 Nov 2023"}' localhost:8099/api/stock/delete






